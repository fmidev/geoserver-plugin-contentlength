package fi.fmi.geoserver.contentlength;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import org.geoserver.ows.DispatcherCallback;
import org.geoserver.ows.Request;
import org.geoserver.ows.Response;
import org.geoserver.platform.Operation;
import org.geoserver.platform.Service;
import org.geoserver.platform.ServiceException;

/**
 * Forces Content-Length into headers given by {org.geoserver.ows.Response}.
 *
 * <p>DispatcherCallback extensions are automatically loaded by GeoServer framework. Framework
 * {org.geoserver.ows.Dispatcher} instance calls {responseDispatched} callback function of
 * {org.geoserver.ows.DispatcherCallback} instances before flushing response output stream. Therefore, callback may add
 * additional header into response before flush is done.
 *
 * <p>This class uses {ContentLengthResponse} to get the content length from the stream content.
 */
public class ContentLengthDispatcherCallback implements DispatcherCallback {

    private static final Logger LOGGER = Logger.getLogger(ContentLengthDispatcherCallback.class.getName());

    /** See parent {org.geoserver.ows.DispatcherCallback} class for function description. */
    public Request init(Request request) {
        // Nothing to do.
        return null;
    }

    /** See parent {org.geoserver.ows.DispatcherCallback} class for function description. */
    public Service serviceDispatched(Request request, Service service) throws ServiceException {
        // Nothing to do.
        return null;
    }

    /** See parent {org.geoserver.ows.DispatcherCallback} class for function description. */
    public Operation operationDispatched(Request request, Operation operation) {
        // Nothing to do.
        return null;
    }

    /** See parent {org.geoserver.ows.DispatcherCallback} class for function description. */
    public Object operationExecuted(Request request, Operation operation, Object result) {
        // Nothing to do.
        return null;
    }

    /**
     * Called after the response to a request has been dispatched.
     *
     * <p>Wraps the given {response} if Content-Length should be included as part of the {response} headers.
     *
     * <p><b>Note:</b> This method is only called when the operation returns a value.
     *
     * <p>This method can modify the response object, or wrap and return it. If null is returned the response passed in
     * is used normally.
     *
     * @param request The request.
     * @param operation The operation.
     * @param result The result of the operation.
     * @param response The response to the operation.
     */
    public Response responseDispatched(Request request, Operation operation, Object result, Response response) {
        Response wrapperResponse = null;
        try {
            ContentLengthResponse contentLengthResponse = new ContentLengthResponse(response);
            // Set the content length header.
            if (contentLengthResponse.setContentLength(request, operation, result, response)) {
                // Use the wrapper response in the framework flow
                // because Content-Length header was set.
                wrapperResponse = contentLengthResponse;
            }

        } catch (final Exception e) {
            // ContentLengthResponse measures the size by writing the response once into a
            // buffer, which for responses such as RenderedImageMapResponse already disposes
            // the underlying result (e.g. WMSMapContent) as a side effect. Swallowing this
            // failure and returning null here would make the framework write the very same,
            // now-disposed result a second time, turning this real error into a confusing,
            // unrelated NullPointerException later on. Report the original failure instead.
            LOGGER.log(Level.WARNING, "Failed to set Content-Length for request " + requestUrl(request), e);
            throw new ServiceException("Failed to render response for request " + requestUrl(request), e);
        }
        return wrapperResponse;
    }

    /** Builds the full request URL (including query string), or a placeholder if unavailable. */
    private static String requestUrl(Request request) {
        HttpServletRequest httpRequest = request != null ? request.getHttpRequest() : null;
        if (httpRequest == null) {
            return "<unknown>";
        }
        StringBuilder url = new StringBuilder(httpRequest.getRequestURL());
        String queryString = httpRequest.getQueryString();
        if (queryString != null) {
            url.append('?').append(queryString);
        }
        return url.toString();
    }

    /** See parent {org.geoserver.ows.DispatcherCallback} class for function description. */
    public void finished(Request request) {
        // Nothing to do.
    }
}
